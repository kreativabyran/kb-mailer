jQuery( document ).ready(
	function( $ ) {
		$( '.kbm-color-pickers' ).wpColorPicker();
	}
);